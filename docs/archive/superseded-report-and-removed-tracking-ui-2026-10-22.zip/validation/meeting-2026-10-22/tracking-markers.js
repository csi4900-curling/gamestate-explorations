// Display-only: endpoints refer to retained observations, not physical visibility.
const trackingPanel=document.createElement('div');
trackingPanel.className='box';
trackingPanel.innerHTML='<b>Tracking coverage — selected camera segment</b><p id="tracking-state" aria-live="polite"></p><button id="tracking-last">Show last tracked frame</button> <button id="tracking-after">Show 1 s after track ends</button><p id="tracking-bounds"></p><small>A red cross marks the LAST recorded position, not the stone’s current location. Track end may mean detector loss, a camera cut, filtering or an analysis boundary; it does not prove the stone became invisible. Geometry rejection is separate from tracking loss.</small>';
document.querySelector('#details').after(trackingPanel);
const trackStamp=t=>`${Math.floor(t/60)}:${(t%60).toFixed(2).padStart(5,'0')}`;
function trackingState(segment,t){
 const pts=segment?.pixel_points||[];
 if(!pts.length)return {kind:'empty',label:'No retained pixel track for this selection.'};
 const first=pts[0],last=pts[pts.length-1];
 if(t<first.time_s-.04)return {kind:'before',label:`No retained observation yet. First: ${trackStamp(first.time_s)}.`};
 if(t>last.time_s+.04)return {kind:'ended',point:last,label:`TRACK ENDED — last observation ${trackStamp(last.time_s)}; ${(t-last.time_s).toFixed(2)} s ago. No continuation retained in this segment.`};
 let previous=null;
 for(const next of pts){
  if(previous && next.time_s-previous.time_s>1.6 && t>previous.time_s+.04 && t<next.time_s-.04)
   return {kind:'gap',point:previous,label:`OBSERVATION GAP — last ${trackStamp(previous.time_s)}; next retained observation ${trackStamp(next.time_s)}. Identity across the gap is not verified.`};
  previous=next;
 }
 const point=pts.reduce((a,b)=>Math.abs(a.time_s-t)<Math.abs(b.time_s-t)?a:b);
 return {kind:'tracked',point,label:`Within retained track — nearest observation ${trackStamp(point.time_s)} (sampled, not every video frame).`};
}
function trackingJump(after){
 const pts=D[ei]?.segments[si]?.pixel_points||[];
 if(!pts.length||v.readyState<1)return;
 v.pause();v.currentTime=Math.min(v.duration,pts[pts.length-1].time_s+after);
}
document.querySelector('#tracking-last').onclick=()=>trackingJump(0);
document.querySelector('#tracking-after').onclick=()=>trackingJump(1);
function drawTrackingMarker(){
 const segment=D[ei]?.segments[si];const pts=segment?.pixel_points||[];
 const state=trackingState(segment,v.currentTime);
 document.querySelector('#tracking-state').textContent=state.label;
 for(const id of ['tracking-last','tracking-after'])document.getElementById(id).disabled=!pts.length;
 document.querySelector('#tracking-bounds').textContent=pts.length?`${segment.camera}: ${trackStamp(pts[0].time_s)} → ${trackStamp(pts[pts.length-1].time_s)} · ${pts.length} retained pixel observations.`:'';
 o.save();
 o.fillStyle='rgba(0,0,0,.8)';o.fillRect(0,0,640,24);
 o.font='bold 12px sans-serif';o.fillStyle=['ended','gap'].includes(state.kind)?'#ff8e8e':'#ffffff';
 const banner=state.kind==='ended'?`TRACK ENDED · last observation ${trackStamp(state.point.time_s)} · ${segment.camera}`:state.kind==='gap'?`OBSERVATION GAP · last observation ${trackStamp(state.point.time_s)}`:state.kind==='tracked'?`RETAINED TRACK · ${segment.camera} · sample ${trackStamp(state.point.time_s)}`:state.label;
 o.fillText(banner,8,16);
 if(['ended','gap'].includes(state.kind)&&v.currentTime-state.point.time_s<=2){
  const [x,y]=state.point.pixel;o.strokeStyle='#ff5252';o.lineWidth=3;o.beginPath();o.moveTo(x-10,y-10);o.lineTo(x+10,y+10);o.moveTo(x+10,y-10);o.lineTo(x-10,y+10);o.stroke();
  const tx=Math.max(4,Math.min(480,x+14)),ty=Math.max(40,Math.min(338,y+20));o.fillStyle='rgba(0,0,0,.85)';o.fillRect(tx-3,ty-13,154,20);o.fillStyle='#ffaaaa';o.fillText('LAST POSITION (historical)',tx,ty);
 }else if(state.kind==='tracked'&&Math.abs(v.currentTime-pts[pts.length-1].time_s)<=.04){
  const [x,y]=state.point.pixel;o.strokeStyle='#ffb830';o.lineWidth=3;o.beginPath();o.arc(x,y,13,0,Math.PI*2);o.stroke();o.fillStyle='#ffb830';o.fillText('LAST RETAINED OBSERVATION',Math.max(4,Math.min(425,x+16)),Math.max(40,y));
 }
 o.restore();
}
